# go-agent-lambda
Lambda para buscar tickets de um agente excluído

Requirements
  - Go 1.15+
  - make
  - serverless
